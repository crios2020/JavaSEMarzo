package clase02;

//declaración de clase
public class Auto {
    
    // Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    /**
     * Este método constructor fue deprecado por Carlos Ríos el 15/03/2021, 
     * por considerarse inseguro.
     * Usar en su reemplazo Auto(String marca, String modelo, String color) 
     * @deprecated
     */
    @Deprecated
    Auto(){}    //constructor vacio
    
    // Constructores
    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }
    
    // Métodos
    void acelerar(){                                //acelerar
        velocidad+=10;
        if(velocidad>100) velocidad=100;
    }
    
    //método sobrecargado
    void acelerar(int kilometros){                  //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }
    
    void acelerar(int x,String c){}                 //acelerarIntString
    
    void frenar(){
        velocidad-=10;
    }
    
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    //método que retorna un valor
    int getVelocidad(){
        return velocidad;
    }
    
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
    public String getEstado(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
}//end class