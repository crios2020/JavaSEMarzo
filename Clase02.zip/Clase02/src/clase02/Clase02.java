package clase02;

import javax.swing.JOptionPane;

public class Clase02 {

    public static void main(String[] args) {
        System.out.println("Hola mundo!");
        //JOptionPane.showMessageDialog(null, "Hola Mundo!");
        
        // Clase 02  Programación Orientada a Objetos
        
        /*
        Clase:
        
        Que es una clase? Una clase se encuentra como un sustantivo
        Ej: Cliente, Factura, Articulo.
        
        Una Clase en java es un Objeto de la clase java.lang.Class
        
        Atributo:
        
        Que es un atributo? Un Atributo describe a la clase, es un adjetivo de la clase.
        Son variables contenidas dentro de una clase.
        
        Un Atributo en Java es un Objeto de la clase java.lang.reflect.Field
        Los atributos tienen un proceso de inicilización.
        Los Atributos numericos, se inicializan en 0.
        Los Atributos String, se inicializan en null;
        
        Método:
        Que es un Método? un método es una acción que realiza la clase.
        Se expresa como un verbo.
        
        Un Método en Java es un Objeto de la clase java.lang.reflect.Method
        
        Que es un objeto? Un Objeto representa una situación en particular (Instancia) 
        de una clase.
        Tiene un estado propio (valor en sus atributos). 
        Las clases declaran los atributos y los objetos completan el estado de los atributos
        
        
        Métodos Sobrecargados:
        Son métodos dentro de una misma clase que se llaman igual, pero tienen
        distinta firma de párametros de entrada.
        
        Métodos Constructores:
        Son métodos que se ejecutan al construir un objeto e inicializan el objeto.
        Existe la sobrecarga de constructores.
        Si la clase no tiene constructor Java agrega un constructor vacio al compilar.
        Los constructores tiene el mismo nombre que la clase y no tienen devolución de valor
        
        En Java los constructores con objetos de la clase java.lang.reflect.Constructor
        
        */
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();                  //se llama al constructor
        auto1.marca="Fiat";
        auto1.modelo="Doblo";
        auto1.color="Rojo";
        
        auto1.acelerar();           // 10
        auto1.acelerar();           // 20
        auto1.acelerar();           // 30
        auto1.frenar();             // 20
        auto1.acelerar(23);         // 43
        
        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Renault";
        auto2.modelo="Kangoo";
        auto2.color="Bordo";
        
        for(int a=0;a<=50;a++) auto2.acelerar();
        
        System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);
        
        auto2.imprimirVelocidad();
        System.out.println(auto2.getVelocidad());
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.getVelocidad());
        
        // Métodos Constructores
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Peugeot", "Partner", "Gris");
        auto3.acelerar(11);
        
        // Método toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        System.out.println(auto3.getEstado());
        
        
        /*
        ************************************************************************
                    Temas pendientes
        
        -   Getters & Setters.
        -   Modificadores de Visibilidad.
        
        ************************************************************************
        */
        
        
        
        
        
        int x;
        String x2;
        //System.out.println(x);                //Error hay que inicializar la variable
        //System.out.println(x2);               //Error
        
        
        //declaración de clase interna
        class Moto{
            String marca;
        }
        
        Moto moto1=new Moto();
        
    }

}
