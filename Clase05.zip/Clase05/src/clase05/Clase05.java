package clase05;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Clase05 {

    public static void main(String[] args){
        // Clase 05 Manejo de Excpetions
        System.out.println("Hola, Hoy es Lunes!!");
       
        /*
        System.out.println(10/0);
        System.out.println("Esta linea no se ejecuta!!!");
        */
        
        
        /*
        
        //Bloque try - catch - finally
        
        try{                            // obligatorio
            // Colocar en este bloque todas las sentencias que pueden lanzar
            // Exceptions.
            // Estas sentencias tiene más consumo de hardware.
            // Si este bloque se puede ejecutar con normalidad, termina con normalidad
            // se pasa el control de ejecución al bloque finally.
            // Si ocurre una exception se detiene el control de este bloque y continua la
            // ejecución en el bloque catch.
        
        }catch(Exception e){            // obligatorio
            //Este bloque se ejecuta solo en caso de existir exception en el bloque try.
            //Se recibe como parametro un objeto de la clase Exception, con la descripcion
            // de la exception.
            //Luego de ejecutar este bloque se pasa el control de ejecución al bloque finally.
        }finally{                       // opcional
            //El bloque finally se ejecuta siempre.
            //Las variables declaradas en Try o Catch esta fuera de alcance(Scope)
        }
        //El programa termina con normalidad.
        */
        
        /*
        try{
            System.out.println("Chau Mundo!!!");
            System.out.println(10/1);
            System.out.println("Esta sentencia no se ejecuta");
        }catch(Exception e){
            System.out.println("Ocurrio un error!!!");
            System.out.println(e);
        }finally{
            System.out.println("bloque finally");
        }
        System.out.println("El programa termina normalmente.");
        */
        
//        try {
//            GeneradorDeExceptions.generar("hola",8);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
        
        //Unchecked Exception
        //GeneradorDeExceptions.generar(true);
        
        
        //Checked Exception
        //FileReader in=new FileReader(new File("texto.txt"));
        //in.read();
        //in.close();
        
   
        //Captura personalizada de Exceptions
        /*
        try {
            //GeneradorDeExceptions.generar("26x");
            FileReader in=new FileReader(new File("texto.txt"));
            in.read();
            in.close();
        //} catch (ArrayIndexOutOfBoundsException e){ System.out.println("Indice Fuera de Rango!");
        //} catch (StringIndexOutOfBoundsException e){ System.out.println("Indice Fuera de Rango!");
        //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e){ 
        //    System.out.println("Indice Fuera de Rango!");
        } catch (IndexOutOfBoundsException e){ System.out.println("Indice Fuera de Rango!");
        } catch (NumberFormatException e){ System.out.println("Numero Incorrecto!");
        } catch (ArithmeticException e) { System.out.println("División x 0!");
        } catch (NullPointerException e){ System.out.println("Puntero nulo!");  
        } catch (FileNotFoundException e) { System.out.println("No se encontro el archivo!");
        } catch (IOException e) { System.out.println("Error I/O");
        } catch (Exception e) { System.out.println("Ocurrio un error no esperado!");
        }
        */
        
        //Manejo de Exceptions para validar reglas de negocio
        Vuelo v1=new Vuelo("AER1234", 100);
        Vuelo v2=new Vuelo("PEA1111", 100);
        
        try{
            v1.venderPasajes(150);
        }catch(Exception e){ 
            System.out.println(e);
        }
        
        try{
            v2.venderPasajes(20);
        }catch(Exception e){ 
            System.out.println(e);
        }
        
        System.out.println(v1);
        System.out.println(v2);
        
        // try with resources       JDK 7
        try (Lector lector=new Lector("texto.txt")) {
            System.out.println(lector.read());
            //throw new Exception();
            //lector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        
        // Esto no se debe hacer!!!
        /*
        Lector lector=null;
        try {
            lector=new Lector("texto.txt");
            System.out.println(lector.read());
            lector.close();
        } catch (Exception e) {
            System.out.println(e);
            if(lector==null){
                try{
                    lector.close();
                }catch(Exception ex){
                    System.out.println(ex);
                }
            }
        }
        */
        
        
    }

}
