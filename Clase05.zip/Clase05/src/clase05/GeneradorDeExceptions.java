package clase05;

public class GeneradorDeExceptions {
    public static void generar(){
        int[] vector=new int[5];
        vector[10]=20;
    }
    public static void generar(boolean x){
        if(x) System.out.println(10/0);
    }
    public static void generar(String nro){         // "22x"
        int n=Integer.parseInt(nro);
    }
    public static void generar(String texto, int index){        //null, 20
        //if(texto==null || index<0 || index>=texto.length()) return;
        System.out.println(texto.charAt(index));
    }
}