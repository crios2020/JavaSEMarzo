package clase05;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Lector implements Closeable{
    public Lector(String file) throws FileNotFoundException{
        System.out.println("Se abrio un archivo!");
    }
    
    public String read(){
        return "contenido de archivo!";
    }

    @Override
    public void close() throws IOException {
        System.out.println("Se cerro un archivo!");
    }
}