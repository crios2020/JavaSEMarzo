package clase05;

public class NoHayMasPasajesException extends Exception {
    private String nombreVuelo;
    private int cantidadPasajesVuelo;
    private int cantidadPasajesPedida;

    public NoHayMasPasajesException(String nombreVuelo, int cantidadPasajesVuelo, int cantidadPasajesPedida) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesVuelo = cantidadPasajesVuelo;
        this.cantidadPasajesPedida = cantidadPasajesPedida;
    }
    
    @Override
    public String toString() {
        return "El vuelo "+nombreVuelo+", no tiene "+cantidadPasajesPedida+", solo tiene "+cantidadPasajesVuelo+" pasajes.";
    }

    @Override
    public String getMessage() {
        return this.toString();
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public int getCantidadPasajesVuelo() {
        return cantidadPasajesVuelo;
    }

    public int getCantidadPasajesPedida() {
        return cantidadPasajesPedida;
    }
   
}