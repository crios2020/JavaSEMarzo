package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.ArrayList;

public class TestDiagramaRelaciones {
    public static void main(String[] args) {
        
        //Objetos Mocks
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(60000);
        cuenta1.depositar(50000);
        cuenta1.debitar(25000);
        System.out.println(cuenta1);
 
        System.out.println("-- cliente1 --");
        ClientePersona cliente1=new ClientePersona(1, "Juan", 25, new Cuenta(2,"arg$"));
        cliente1.getCuenta().depositar(26000);
        System.out.println(cliente1);
        
        System.out.println("-- cliente2 --");
        ClientePersona cliente2=new ClientePersona(2, "Ana", 25, cliente1.getCuenta());
        cliente2.getCuenta().debitar(6000);
        System.out.println(cliente2);
        System.out.println(cliente1);
        
        System.out.println("-- cliente3 --");
        ClientePersona cliente3=new ClientePersona(3, "Luis",22, 3, "arg$");
        cliente3.getCuenta().depositar(45000);
        System.out.println(cliente3);
        
        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1, "Wiskeria", "Larrea 123");
        
        ArrayList<Cuenta>lista=clienteEmpresa1.getCuentas();
        
        clienteEmpresa1.getCuentas().add(new Cuenta(10,"arg$"));            // 0
        lista.add(new Cuenta(11,"reales"));          // 1
        lista.add(new Cuenta(12,"u$s"));             // 2
                
        lista.get(0).depositar(78000);
        lista.get(0).depositar(35000);
        lista.get(0).debitar(2300);
        lista.get(1).depositar(25600);
        lista.get(2).depositar(12000);
        
        System.out.println(clienteEmpresa1);
        for(int a=0 ;a<lista.size();a++) System.out.println(lista.get(a));
        
        
    }
}