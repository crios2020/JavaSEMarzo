package paquetex;

import clase02.Auto;

public class ClaseX {
    public static void main(String[] args) {
        Auto autoX=new Auto("Ferrari", "Testarosa", "Rojo");
        //autoX.marca="Ford";
    }
}