package ar.org.centro8.curso.java.utils.html;

import java.lang.reflect.Field;
import java.util.List;

public class Table<E> {

    public String getTable(List<E> list) {
        String table = "";
        if (list == null || list.isEmpty()) {
            return table;
        }
        table += "<table border=1 style='border-style: solid;'>\n";
        E e = list.get(0);
        Field[] campos = e.getClass().getDeclaredFields();
        table += "<tr>";
        for (Field c : campos) {
            table += "<th>" + c.getName() + "</th>";
        }
        table += "</tr>\n";
        for (E x : list) {
            table += "<tr>";
            for (Field c : campos) {
                table += "<td>";
                String method = "get" + c.getName().substring(0, 1).toUpperCase() + c.getName().substring(1);
                //table+=method;
                try {
                    table += e.getClass().getMethod(method, null).invoke(x, null);
                } catch (Exception ex) {
                    System.out.println(ex);
                }
                table += "</td>";
            }
            table += "</tr>\n";
        }
        table += "</table>\n";
        return table;
    }

    public String getTable(List<E> list, String linkDelete) {
        String table = "";
        if (list == null || list.isEmpty()) {
            return table;
        }
        table += "<table border=1 style='border-style: solid;'>\n";
        E e = list.get(0);
        Field[] campos = e.getClass().getDeclaredFields();
        table += "<tr>";
        for (Field c : campos) {
            table += "<th>" + c.getName() + "</th>";
        }
        table += "<th>Borrar</th>";
        table += "</tr>\n";
        for (E x : list) {
            table += "<tr>";
            for (Field c : campos) {
                table += "<td>";
                String method = "get" + c.getName().substring(0, 1).toUpperCase() + c.getName().substring(1);
                //table+=method;
                try {
                    table += e.getClass().getMethod(method, null).invoke(x, null);
                } catch (Exception ex) {
                    System.out.println(ex);
                }
                table += "</td>";
            }
            try {
                table += "<td>"
                        + "<a href=" + linkDelete 
                        + "?id="+ e.getClass().getMethod("getId", null).invoke(x, null) 
                        + ">borrar</a>"
                        + "</td>";
            } catch (Exception ex) {
                System.out.println(ex);
            }
            table += "</tr>\n";
        }
            table += "</table>\n";
            return table;
        }
    
}
