package colleciones;

import java.util.ArrayDeque;

public class Pila<E> extends ArrayDeque<E> {

    @Override
    public E poll(){
        throw new RuntimeException();
    }

    @Override
    public boolean offer(E e) {
        return false; 
    }

    @Override
    public E pollLast() {
        return null;
    }

    @Override
    public E pollFirst() {
        return null; 
    }

    @Override
    public boolean offerLast(E e) {
        return false;
    }

    @Override
    public boolean offerFirst(E e) {
        return false;
    }
    
}