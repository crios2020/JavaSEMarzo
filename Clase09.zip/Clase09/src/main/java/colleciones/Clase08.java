package colleciones;

//import java.util.*;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

public class Clase08 {
    public static void main(String[] args) {
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Gris");
        autos[1]=new Auto("Ford","Ka","Negro");
        autos[2]=new Auto("Peugeot","206","Rojo");
        autos[3]=new Auto("Honda","City","Blanco");
        
        //recorrido con indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        //estructura forEach
        for(Auto a:autos) System.out.println(a);
        
        //Interface List    Representa una lista con indices y permite contener
        //                  valores duplicados.
        
        List list=new ArrayList();
        
        list.add(new Auto("Hiuday","i20","Rojo"));             // 0
        list.add(new Auto("Kia","Picanto","Rojo"));             // 2
        list.add(1, new Auto("Renault","Clio","Bordo"));        // 1
        list.add("Hola");                                       // 3
        list.add("Chau");                                       // 4
        list.add(26);                                           // 5
        
        //list.remove("Chau");
        list.remove(4);
        
        //Copiar los autos del vector autos a list
        for(Auto a:autos) list.add(a);
        
        System.out.println("****************************************************");
        // Recorrido con indices
        //for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        // Recorrido foreach
        //for(Object o:list) System.out.println(o);
        
        // método .forEach() JDK 8 o sup.
        //list.forEach(o->System.out.println(o));
        list.forEach(System.out::println);
        
        
        //Uso de Generics <>    JDK 5 o sup.
        List<Auto>list2=new ArrayList();
        list2.add(new Auto("Citroen","C4","Gris"));
        
        Auto a1=(Auto)list.get(0);
        Auto a2=list2.get(0);
        
        //copiar los autos de list a list2
        list.forEach(o->{
            if(o instanceof Auto) list2.add((Auto)o);
        });
        //list.forEach(o->{
        //    try {
        //        list2.add((Auto)o);
        //    } catch (Exception e) { }
        //});
        
        
        System.out.println("****************************************************");
        list2.forEach(System.out::println);
        
        
        //Interface SET
        
        Set<String> set;
        
        //Implementación HashSet: es la más veloz, pero  no garantiza el orden de
        //                          los elementos.
        //set=new HashSet();
        
        //Implementación LinkedHashSet: almacena elementos en una lista enlazada
        //                          por orden de ingreso.
        //set=new LinkedHashSet();
        
        //Implementación TreeSet: almacena elementos en un arbol por orden natural.
        set=new TreeSet();
        
        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Lunes");
        set.add("Martes");
        set.add("Viernes");
        set.add("Sábado");
        set.add("Domingo");
        set.forEach(System.out::println);
        
        Set<Auto>setAutos=new TreeSet();
        setAutos.add(new Auto("Chevrolet","Spark","Rojo"));
        setAutos.addAll(list2);
        setAutos.add(new Auto("Citroen","C4","Gris"));
        setAutos.add(new Auto("Citroen","Berlingo","Rojo"));
        setAutos.add(new Auto("Citroen","C5","Blanco"));
        setAutos.add(new Auto("Citroen","C3","Negro"));
        //setAutos.add(list2.get(0));
        
        System.out.println("****************************************************");
        setAutos.forEach(a->System.out.println(a+"\t"+a.hashCode()));
        
        //Pilas y Colas
        /*
            Cola ArrayDeque     FIFO    First In First Out
        
        
            Pila Stack          LIFO    Last In Fisrt Out
        
        */
        
        // colas ArrayDeque
        ArrayDeque<Auto> colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("Ford","Fiesta","Verde"));
        // .offer() Encola un elemento
        colaAutos.addAll(list2);
        System.out.println("****************************************************");
        colaAutos.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("Longitud de Cola: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.pop());
            // .pop() Desencola un elemento
        }
        System.out.println("Longitud de Cola: "+colaAutos.size());
        
        // pilas Stack      Legacy
        Stack<Auto>pilaAutos=new Stack();
        pilaAutos.push(new Auto("Renault","Twingo","Verde"));
        // .push() Apila un elemento en la pila
        pilaAutos.addAll(list2);
        System.out.println("****************************************************");
        pilaAutos.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("Longitud de Pila: "+pilaAutos.size());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
            // .pop() Desapila un elemento en la pila
        }
        System.out.println("Longitud de Pila: "+pilaAutos.size());
        
        //Pila usando ArrayDeque
        ArrayDeque<Auto>pilaAutos2=new ArrayDeque();
        pilaAutos2.push(new Auto("Fiat","Uno","Blanco"));
        pilaAutos2.addAll(list2);
        System.out.println("****************************************************");
        pilaAutos2.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("Longitud de pila: "+pilaAutos2.size());
        while(!pilaAutos2.isEmpty()){
            System.out.println(pilaAutos2.removeLast());
        }
        System.out.println("Longitud de pila: "+pilaAutos2.size());
        System.out.println("****************************************************");
        System.out.println("");
        
        System.out.println("-- API Stream --");
        //select * from autos where color='Rojo';
        list2
                .stream()
                .filter(a->a.getColor().equals("Rojo"))
                .forEach(System.out::println);
        System.out.println("****************************************************");
        List<Auto>listRojo=new ArrayList();
        for(Auto a:list2){
            if(a.getColor().equals("Rojo")) listRojo.add(a);
        }
        for(Auto a:listRojo) System.out.println(a);
        
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        
        System.out.println("****************************************************");
        // select * from alumnos where edad>30
        ar
                .getAll()
                .stream()
                .filter(a->a.getEdad()>30)
                .forEach(System.out::println);
        System.out.println("****************************************************");
        List<Alumno> listMayor30=new ArrayList();
        for(Alumno a:ar.getAll()){
            if(a.getEdad()>30) listMayor30.add(a);
        }
        for(Alumno a:listMayor30) System.out.println(a);
        
        System.out.println("****************************************************");
        // select * from autos where color='rojo';
        
        // rojo Rojo ROJO rojO
        list2
                .stream()
                .filter(a->a.getColor().equalsIgnoreCase("rojo"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from alumnos where nombre like '%ca%';
        ar
                .getAll()
                .stream()
                .filter(a->a.getNombre().toLowerCase().contains("ca"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from alumnos where nombre like 'ca%';
        ar
                .getAll()
                .stream()
                .filter(a->a.getNombre().toLowerCase().startsWith("ca"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from alumnos where nombre like '%ca%' and edad>35;
        ar
                .getAll()
                .stream()
                .filter(a->a.getNombre().toLowerCase().contains("ca")
                        && a.getEdad()>35)
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        // select * from alumnos order by apellido;
        ar
                .getAll()
                .stream()
                .sorted(Comparator.comparing(Alumno::getApellido))
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        // select * from alumnos order by apellido desc, nombre desc;
        ar
                .getAll()
                .stream()
                .sorted(Comparator
                        .comparing(Alumno::getApellido)
                        .thenComparing(Alumno::getNombre)
                        .reversed())
                .forEach(System.out::println);
        
        
        
    }
}