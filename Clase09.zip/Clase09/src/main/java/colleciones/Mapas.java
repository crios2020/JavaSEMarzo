package colleciones;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Mapas {
    public static void main(String[] args) {
        //Interface Map
        Map<String,String>mapaSemana=null;
        
        //Implementación HashMap: La más Veloz, pero no garantiza el orden.
        //mapaSemana=new HashMap();
        
        //Implementación Hashtable: Es igual a HashMap pero es obsoleta.
        //mapaSemana=new Hashtable();
        
        //Implementación LinkedHashMap: almacena las llaves en una lista enlazada por orden de ingreso
        //mapaSemana=new LinkedHashMap();
        
        //Implementación TreeMap: Almacena las llaves en un arbol por orden natural.
        //mapaSemana=new TreeMap();
        
        //App
        mapaSemana.put("lu", "lunes");
        mapaSemana.put("ma", "martes");
        mapaSemana.put("mi", "miércoles");
        mapaSemana.put("ju", "jueves");
        mapaSemana.put("vi", "viernes");
        mapaSemana.put("sa", "sábado");
        mapaSemana.put("do", "domingo");
        //mapaSemana.put("lu", "xx");
        System.out.println(mapaSemana.get("ju"));
        System.out.println("****************************************************");
        mapaSemana.forEach((k,v)->System.out.println(k+": "+v));
        
        
    }
}