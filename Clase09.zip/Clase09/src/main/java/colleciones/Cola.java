package colleciones;

import java.util.ArrayDeque;

public class Cola<E> extends ArrayDeque<E> {

    @Override
    public E pop() {
        return null;
    }

    @Override
    public void push(E e) {}

    @Override
    public boolean removeLastOccurrence(Object o) {
        return false;
    }

    @Override
    public E removeLast() {
        return null;
    }

}