package ar.com.eduit.curso.java.repositories.interfaces;

import ar.com.eduit.curso.java.entities.Curso;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_CursoRepository {
    void save(Curso curso);
    void remove(Curso curso);
    void update(Curso curso);
    List<Curso>getAll();
    default Curso getById(int id){
        return  getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findAny()
                .orElse(new Curso());
    }
    default List<Curso>getLikeTitulo(String titulo){
        if(titulo==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getTitulo()!=null && c.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                .collect(Collectors.toList());
    }
}