package ar.com.eduit.curso.java.test;

public class TestFiles {
    public static void main(String[] args) {
        
    }
}