package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.util.List;

public class TestRepository {
    public static void main(String[] args) {
        
        System.out.println("****************************************************");
        System.out.println("    CURSOS  ");
        System.out.println("****************************************************");
        
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("Hibernate", "Toloza", Dia.JUEVES, Turno.TARDE);
        cr.save(curso);
        System.out.println(curso);
        
        System.out.println("****************************************************");
        System.out.println(cr.getById(8));
        System.out.println(cr.getById(60000));
        
        System.out.println("****************************************************");
        cr.remove(cr.getById(23));
        
        System.out.println("****************************************************");
        curso=cr.getById(24);
        if(curso!=null && curso.getId()!=0){
            curso.setTitulo("Python");
            curso.setProfesor("Pedro");
            cr.update(curso);
        }
        
        System.out.println("****************************************************");
        //List<Curso>listCursos=cr.getAll();
        //for(int a=0;a<listCursos.size();a++) System.out.println(listCursos.get(a));
        cr.getAll().forEach(System.out::println);
        
        System.out.println("****************************************************");
        //listCursos=cr.getLikeTitulo("jar");
        //for(int a=0;a<listCursos.size();a++) System.out.println(listCursos.get(a));
        cr.getLikeTitulo("jar").forEach(System.out::println);
        
        System.out.println("****************************************************");
        System.out.println("    ALUMNOS  ");
        System.out.println("****************************************************");
        
        
        System.out.println("****************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
       
        Alumno alumno=new Alumno("Carola","deMarchi",38,2);
        ar.save(alumno);
        System.out.println(alumno);
        
        System.out.println("****************************************************");
        ar.remove(ar.getById(10));
        
        System.out.println("****************************************************");
        alumno = ar.getById(11);
        if(alumno!=null && alumno.getId()>0){
            alumno.setIdCurso(5);
            ar.update(alumno);
        }
        
        System.out.println("****************************************************");
        System.out.println(ar.getById(4));
        
        System.out.println("****************************************************");
        //List<Alumno> listAlumnos=ar.getAll();
        //for(int a=0;a<listAlumnos.size(); a++) System.out.println(listAlumnos.get(a));
        ar.getAll().forEach(System.out::println);
        
        System.out.println("****************************************************");
        //listAlumnos=ar.getLikeApellido("re");
        //for(int a=0;a<listAlumnos.size(); a++) System.out.println(listAlumnos.get(a));
        ar.getLikeApellido("re").forEach(System.out::println);
        
        System.out.println("****************************************************");
        //listAlumnos=ar.getByCurso(cr.getById(1));
        //for(int a=0;a<listAlumnos.size(); a++) System.out.println(listAlumnos.get(a));
        ar.getByCurso(cr.getById(1)).forEach(System.out::println);
        
    }
}