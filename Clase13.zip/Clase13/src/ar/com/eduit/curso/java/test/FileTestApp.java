package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.utils.file.FileText;
import ar.com.eduit.curso.java.utils.file.I_File;
import java.util.List;

public class FileTestApp {
    public static void main(String[] args) {
        String file="texto.txt";
        I_File fText=new FileText(file);
        fText.setText("Curso de Java.\n");
        fText.appendText("Hoy es Miércoles.\n");
        
        fText.addLine("Primavera.");
        fText.addLine("Verano.");
        fText.addLine("Otoño.");
        fText.addLine("Invierno.");
        fText.addLine("Primavera.");
        fText.addLine("Verano.");
        fText.addLines(List.of("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo","Lunes"));
        
        fText.remove("Invierno.");
        
        //System.out.println(fText.getText());
        //fText.print();
        fText.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        fText.getLikeFilter("M").forEach(System.out::println);
        System.out.println("****************************************************");
        fText.getLinkedHashSet().forEach(System.out::println);
        System.out.println("****************************************************");
        fText.getTreeSet().forEach(System.out::println);
        System.out.println("****************************************************");
        fText.getSortedLines().forEach(System.out::println);
        System.out.println("****************************************************");
        fText.getReversedSortedLines().forEach(System.out::println);
        
        /*
        //"hola"
        String text="";
        System.out.println(text+"\t"+text.hashCode());
        text+="h";
        System.out.println(text+"\t"+text.hashCode());
        text+="o";
        System.out.println(text+"\t"+text.hashCode());
        text+="l";
        System.out.println(text+"\t"+text.hashCode());
        text+="a";
        System.out.println(text+"\t"+text.hashCode());
        
        StringBuilder sb=new StringBuilder();
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("h");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("o");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("l");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("a");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        
        //for(int a=0;a<=400000;a++) text+="x";
        for(int a=0;a<=400000;a++) sb.append("x");
        */
    }
}