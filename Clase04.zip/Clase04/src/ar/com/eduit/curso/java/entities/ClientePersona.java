package ar.com.eduit.curso.java.entities;

public class ClientePersona {
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;
    
    //public ClientePersona(){} //constructor vacio
    
    //un cliente puede ser creado sin cuenta.
    /*
    public ClientePersona(int nro, String nombre, int edad){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
    }
    */
    
    //El cliente debe ser creado con una cuenta
    //La cuenta puede pertenecer a otro cliente.
    public ClientePersona(int nro,String nombre, int edad, Cuenta cuenta){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = cuenta;
    }
    
    //La cuenta solo le pertenece al cliente, le creo su propia cuenta.
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta, String moneda){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = new Cuenta(nroCuenta,moneda);
    }

    @Override
    public String toString() {
        return "ClientePersona{" + "nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + '}';
    }
     
    //A un cliente se le puede agregar o cambiar la cuenta.
    public void setCuenta(Cuenta cuenta){
        this.cuenta=cuenta;
    }
    
    public Cuenta getCuenta(){
        return cuenta;
    }
    
}