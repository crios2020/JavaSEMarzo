package ar.com.eduit.curso.java.interfaces;

public interface I_File {
    /*
    Interfaces:
    
    - No tiene atributos ni constructores.
    - Solo tiene constantes y métodos abstractos.
    - Todos sus miembros son publicos.
    - Una clase puede implementar muchas interfaces.
    
    */
    
    /**
     * La Java Doc es Heredada!
     * @param text 
     */
    void setText(String text);
    String getText();
    
    /*
    Método default JDK8 o sup.
    */
    default void info(){
        System.out.println("Interface I_File");
    }
    
}