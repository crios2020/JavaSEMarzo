package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestDiagramaHerencia {
    public static void main(String[] args) {
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(60000);
        cuenta1.depositar(50000);
        cuenta1.debitar(25000);
        System.out.println(cuenta1);
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Lima", 111, "1", "a");
        System.out.println(dir1);
        
        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Belgrano", 42, null, null, "Morón");
        System.out.println(dir2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Marianela", 23, dir2);
        System.out.println(persona1);
        persona1.saludar();
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Karina",38, persona1.getDireccion());
        System.out.println(persona2);
        persona2.saludar();
        */
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(1, "Matias", 30, dir1, 95000);
        System.out.println(vendedor1);
        vendedor1.saludar();
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1, cuenta1, "Alejandro", 40, dir2);
        cliente1.getCuenta().depositar(30000);
        cliente1.setDireccion(new Direccion("Larrea",234,"1","e"));
        System.out.println(cliente1);
        cliente1.saludar();
        
        
        System.out.println("** Polimorfismo ************************************");
        Persona p1=new Vendedor(2,"Laura",23,dir1,60000);
        Persona p2=new Cliente(2,cuenta1,"Dario",56,dir1);
        
        p1.saludar();
        p2.saludar();
        
        Object x;
        x=20;
        x="Hola";
        x=p1;
        
        System.out.println(p1.getClass());
        System.out.println(p1.getClass().getSuperclass());
        System.out.println(p1.getClass().getSuperclass().getSuperclass());
        System.out.println("Hola".getClass());
        System.out.println("Hola".getClass().getSuperclass());
        System.out.println(p1.getClass().getSuperclass().getSuperclass().getSuperclass());
        
        //Casteo
        Vendedor v1=(p1 instanceof Vendedor)?(Vendedor)p1:null;
        
        
    }
}