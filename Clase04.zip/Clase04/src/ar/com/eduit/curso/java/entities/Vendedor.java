package ar.com.eduit.curso.java.entities;

public class Vendedor extends Persona{
    private int nroLegajo;
    private double sueldoBasico;
    
    public Vendedor(int nroLegajo, String nombre, int edad, Direccion direccion, double sueldoBasico){
        //super() invoca un constructor de la clase Padre
        super(nombre,edad,direccion);
        this.nroLegajo = nroLegajo;
        this.sueldoBasico = sueldoBasico;
    }
    
    @Override
    public void saludar(){
        System.out.println("Hola soy un vendedor!");
    }

    
    @Override
    public String toString(){
        //super invoca un método de la clase Padre
        return nroLegajo+", "+super.toString()+", "+sueldoBasico;
        //return super.toString()+", "+nroLegajo+", "+sueldoBasico;
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(double sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }
    
}